/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectInterface;

import java.text.MessageFormat;
import javax.swing.JTable;

/**
 *
 * @author Asanka
 */
class tbl_priority {

    static void print(JTable.PrintMode printMode, MessageFormat headder, MessageFormat footer) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
